const help = (prefix, pushname) => {
	return `✪═⟪ *DILBOT* ⟫═✪

      Hai Kak *${pushname}* 

╔═══✪〘  *INFORMATION*  〙✪═══
║
╠➥ DILBOT
╠➥ 2.0
╠➥ CREATOR : FADIL
╠➥ wa.me/6285343788098
║
╠═══✪〘  *LIST MENU* 〙✪═══
║
╠➥ *${prefix}owner*
║
╠➥ *${prefix}info*
║
╠➥ *${prefix}bugreport*
║
╠➥ *${prefix}runtime*
║
╠➥ *${prefix}clone*
║
╠➥ *${prefix}promote [tag]*
║
╠➥ *${prefix}demote [tag]*
║
╠➥ *${prefix}tagall [2] [3] [4] [5]*
║
╠➥ *${prefix}simih [0 atau 1]*
║
╠➥ *${prefix}group [open atau close]*
║
╠➥ *${prefix}setdesc*
║
╠➥ *${prefix}setpp*
║
╠➥ *${prefix}setname [teks]*
║
╠➥ *${prefix}kick [tag]*
║
╠➥ *${prefix}linkgroup*
║
╠➥ *${prefix}ytmp3*
║
╠➥ *${prefix}bahasa*
║
╠➥ *${prefix}chatlist*
║
╠➥ *${prefix}blocklist*
║
╠➥ *${prefix}premiumlist*
║
╠➥ *${prefix}kodenegara*
║
╠➥ *${prefix}cekpremium*
║
╠➥ *${prefix}toimg*
║
╠➥ *${prefix}sticker*
║
╠➥ *${prefix}ttp [teks]*
║
╠➥ *${prefix}sticker nobg [ERROR]*
║
╠➥ *${prefix}tts [kode bahasa] [teks]*
║
╠➥ *${prefix}url2img [tipe] [url]*
║
╠➥ *${prefix}wait*
║
╠➥ *${prefix}ocr*
║
╠➥ *${prefix}nulis*
║
╠➥ *${prefix}setprefix*
║
╠➥ *${prefix}bc*
║
╠➥ *${prefix}setppbot*
║
╠➥ *${prefix}clone*
║
╠➥ *${prefix}virtex*
║
╠➥ *${prefix}meme*
║
╠➥ *${prefix}memeindo*
║
╠➥ *${prefix}tiktok*
║
╠➥ *${prefix}ssweb*
║
╠➥ *${prefix}tomp3*
║
╠➥ *${prefix}welcome*
║
╠➥ *${prefix}exe*
║
╠➥ *${prefix}wa.me*
║
╠➥ *${prefix}jadwaltv*
║
╠➥ *${prefix}lirik*
║
╠➥ *${prefix}beritahoax*
║
╠➥ *${prefix}ytmp4*
║
╠➥ *${prefix}spamcall*
║
╠➥ *${prefix}infonomor*
║
╠➥ *${prefix}neonime*
║
╠➥ *${prefix}bpink*
║
╠➥ *${prefix}joox*
║
╠➥ *${prefix}fb*
║
╠➥ *${prefix}wiki*
║
╠➥ *${prefix}ping*
║
╠➥ *${prefix}semoji*
║
╠➥ *${prefix}testime*
║
╠➥ *${prefix}pokemon*
║
╠➥ *${prefix}kbbi*
║
╠➥ *${prefix}pinterest*
║
╠➥ *${prefix}artinama*
║
╠➥ *${prefix}brainly*
║
╠➥ *${prefix}quotemaker*
║
╠➥ *${prefix}alay*
║
╠➥ *${prefix}rate*
║
╠➥ *${prefix}glitch*
║
╠➥ *${prefix}igstalk*
║
╠➥ *${prefix}quran*
║
╠➥ *${prefix}nekonime*
║
╠➥ *${prefix}send*
║
╠➥ *${prefix}chord*
║
╠➥ *${prefix}jsholat*
║
╠➥ *${prefix}bisakah*
║
╠➥ *${prefix}kapankah*
║
╠➥ *${prefix}truth*
║
╠➥ *${prefix}fml*
║
╠➥ *${prefix}cuaca*
║
╠➥ *${prefix}hidetag*
║
╠➥ *${prefix}covid*
║
╠➥ *${prefix}3dtext*
║
╠➥ *${prefix}trendtwit*
║
╠➥ *${prefix}shorturl*
║
╠➥ *${prefix}map*        
║   
╚═〘 DILBOT 〙`
}

exports.help = help
